# Yo-Momma
The Yo Momma Ritual 
